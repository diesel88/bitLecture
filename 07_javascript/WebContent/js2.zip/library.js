/**
 * jquery 라이브러리의 일부 기능 구현
 */

function mlec(val) {
	var ch = val.charAt(0);
	console.log("ch", ch);
	
	console.log("tag Name", val.substring(1,val.length-1));
	var elements;
	switch(ch) {
	case "#":
		elements = document.querySelector(val);
		break;
	case "<" :
		elements = document.createElement(val.substring(1,val.length-1));
		break;
	default:
		elements = document.querySelectorAll(val);
		break;
	}
	elements.attr = function(name, value) {
		// 배열인 경우
		if (this.length){
			for (var i = 0; i < this.length; i++) {
				this[i].setAttribute(name, value);
			}
		}// 배열이 아닌경우
		else {
			this.setAttribute(name,value);
		}
	};
	return elements;
}

var $ = mlec;